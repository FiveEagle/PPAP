package com.example.pmproject.Service;

import java.util.List;

public interface OfflineShopService  {

    List<OfflineShopService > getAllShops();

    List<String> getAllRegions();

    List<String> getCitiesByRegion(String region);

    List<OfflineShopService > getShopsByRegionAndCity(String region, String city);
}
//region 지역
//city 도시 (예 부천시)