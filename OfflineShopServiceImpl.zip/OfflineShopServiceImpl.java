package com.example.pmproject.Service;

import com.example.pmproject.Repository.OfflineShopRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfflineShopServiceImpl implements OfflineShopService {

    private final OfflineShopRepository offlineShopRepository;

    @Autowired
    public OfflineShopServiceImpl(OfflineShopRepository offlineShopRepository) throws  e{
        this.offlineShopRepository = offlineShopRepository;
    }

    public List<OfflineShop> getAllOfflineShops() {
        return offlineShopRepository.findAll();
    }

    public List<String> getAllRegions() {
        return offlineShopRepository.findAllRegions();
    }

    public List<String> getCitiesByRegion(String region) {
        return offlineShopRepository.findCitiesByRegion(region);
    }

    public List<OfflineShop> getOfflineShopsByRegionAndCity(String region, String city) {
        return offlineShopRepository.findByRegionAndCity(region, city);
    }
}